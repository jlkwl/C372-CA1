const connection = require('./db');
const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const multer = require('multer');
const app = express();

// Controllers
const productController = require('./controllers/ProductController');
const OrderController = require('./controllers/OrderController');

// Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'public/images'),
    filename: (req, file, cb) => cb(null, file.originalname)
});
const upload = multer({ storage });

// Middleware
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use(flash());

// Auth middleware
const checkAuthenticated = (req, res, next) => {
    if (req.session.user) return next();
    req.flash('error', 'Please log in to view this resource');
    res.redirect('/login');
};

const checkAdmin = (req, res, next) => {
    if (req.session.user.role === 'admin') return next();
    req.flash('error', 'Access denied');
    res.redirect('/shopping');
};

// Register validation
const validateRegistration = (req, res, next) => {
    const { username, email, password, address, contact, role } = req.body;

    if (!username || !email || !password || !address || !contact || !role)
        return res.status(400).send('All fields are required');

    if (password.length < 6) {
        req.flash('error', 'Password must be at least 6 characters');
        req.flash('formData', req.body);
        return res.redirect('/register');
    }
    next();
};

// ================= HOME =================
app.get('/', (req, res) => {
    res.render('index', { user: req.session.user });
});

// ================= PRODUCTS =================
app.get('/inventory', checkAuthenticated, checkAdmin, productController.listAllProducts);

app.get('/shopping', checkAuthenticated, productController.listAllProducts);

app.get('/product/:id', checkAuthenticated, productController.getProductById);

app.get('/addProduct', checkAuthenticated, checkAdmin, (req, res) => {
    res.render('addProduct', { user: req.session.user });
});

app.post('/addProduct', checkAuthenticated, checkAdmin, upload.single('image'), productController.addProduct);

app.get('/updateProduct/:id', checkAuthenticated, checkAdmin, productController.renderUpdateProductForm);

app.post('/updateProduct/:id', checkAuthenticated, checkAdmin, upload.single('image'), productController.updateProduct);

app.get('/deleteProduct/:id', checkAuthenticated, checkAdmin, productController.deleteProduct);

// ================= CART =================

// Add to cart
app.post('/add-to-cart/:id', checkAuthenticated, (req, res) => {
    const productId = parseInt(req.params.id);
    const quantityToAdd = parseInt(req.body.quantity, 10) || 1;

    productController.fetchProductById(productId, (err, product) => {
        if (err || !product) {
            req.flash('error', 'Product not found');
            return res.redirect('/shopping');
        }

        if (!req.session.cart) req.session.cart = [];

        const available = product.quantity;
        const existing = req.session.cart.find(i => i.productId == productId);

        if (existing) {
            const newTotal = existing.quantity + quantityToAdd;
            if (newTotal > available) {
                existing.quantity = available;
                req.flash('error', `Only ${available} units available`);
            } else {
                existing.quantity = newTotal;
            }
        } else {
            let qty = Math.min(quantityToAdd, available);
            if (qty <= 0) {
                req.flash('error', `${product.productName} is out of stock`);
                return res.redirect('/shopping');
            }
            req.session.cart.push({
                productId: product.id,
                productName: product.productName,
                price: product.price,
                quantity: qty,
                image: product.image
            });
        }

        res.redirect('/cart');
    });
});

// Cart page
app.get('/cart', checkAuthenticated, (req, res) => {
    res.render('cart', {
        cart: req.session.cart || [],
        user: req.session.user,
        errors: req.flash('error'),
        messages: req.flash('success')
    });
});

// Remove item
app.post('/remove-from-cart/:id', checkAuthenticated, (req, res) => {
    const productId = req.params.id;
    req.session.cart = (req.session.cart || []).filter(i => i.productId != productId);
    req.flash('success', 'Item removed');
    res.redirect('/cart');
});

// Clear cart
app.post('/clear-cart', checkAuthenticated, (req, res) => {
    req.session.cart = [];
    req.flash('success', 'Cart cleared');
    res.redirect('/cart');
});

// Update item quantity
app.post('/cart/update', checkAuthenticated, (req, res) => {
    const { productId, quantity } = req.body;
    const item = (req.session.cart || []).find(i => i.productId == productId);
    if (item) item.quantity = Math.max(1, parseInt(quantity));
    req.flash('success', 'Cart updated');
    res.redirect('/cart');
});

// ================= AUTH =================
app.get('/register', (req, res) => {
    res.render('register', {
        messages: req.flash('error'),
        formData: req.flash('formData')[0]
    });
});

app.post('/register', validateRegistration, (req, res) => {
    const { username, email, password, address, contact, role } = req.body;
    const sql = 'INSERT INTO users (username, email, password, address, contact, role) VALUES (?, ?, SHA1(?), ?, ?, ?)';
    connection.query(sql, [username, email, password, address, contact, role], () => {
        req.flash('success', 'Registration successful');
        res.redirect('/login');
    });
});

app.get('/login', (req, res) => {
    res.render('login', {
        messages: req.flash('success'),
        errors: req.flash('error')
    });
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const sql = 'SELECT * FROM users WHERE email = ? AND password = SHA1(?)';
    connection.query(sql, [email, password], (err, results) => {
        if (!results.length) {
            req.flash('error', 'Invalid email or password');
            return res.redirect('/login');
        }
        req.session.user = results[0];
        req.flash('success', 'Login successful');
        res.redirect(results[0].role === 'user' ? '/shopping' : '/inventory');
    });
});

app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

// ================= ORDERS =================
app.post('/checkout', checkAuthenticated, OrderController.checkout);

app.get('/orders', checkAuthenticated, OrderController.listUserOrders);

app.get('/order/:id', checkAuthenticated, OrderController.viewOrder);

// Search suggestions (for your search bar)
app.get('/search-suggestions', (req, res) => {
    const term = req.query.term || "";
    connection.query(
        "SELECT productName FROM products WHERE productName LIKE ? LIMIT 5",
        [`%${term}%`],
        (err, results) => res.json(results.map(r => r.productName))
    );
});

// ================= SERVER =================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
