const db = require('../db');

const CartDB = {

    getUserCart: (userId, callback) => {
        const sql = `
            SELECT c.productId, c.quantity, p.productName, p.price, p.image
            FROM user_cart c
            JOIN products p ON c.productId = p.id
            WHERE c.userId = ?
        `;
        db.query(sql, [userId], callback);
    },

    addOrUpdateItem: (userId, productId, quantity, callback) => {
        const sql = `
            INSERT INTO user_cart (userId, productId, quantity)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
        `;
        db.query(sql, [userId, productId, quantity], callback);
    },

    updateQuantity: (userId, productId, quantity, callback) => {
        const sql = `UPDATE user_cart SET quantity = ? WHERE userId = ? AND productId = ?`;
        db.query(sql, [quantity, userId, productId], callback);
    },

    removeItem: (userId, productId, callback) => {
        const sql = `DELETE FROM user_cart WHERE userId = ? AND productId = ?`;
        db.query(sql, [userId, productId], callback);
    },

    clearCart: (userId, callback) => {
        const sql = `DELETE FROM user_cart WHERE userId = ?`;
        db.query(sql, [userId], callback);
    }
};

module.exports = CartDB;
